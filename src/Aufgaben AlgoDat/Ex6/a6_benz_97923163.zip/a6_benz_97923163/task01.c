#include <stdio.h>
#include<stdlib.h>
//Roland Benz 97923163
//gcc -o task01 task01.c


int main(void)
{
    	printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    	printf("Hoi Livio,\n Ich bin noch immer dabei, den Rückstand in allen anderen Fächern aufzuarbeiten.\n Beschränke den Aufwand deshalb auf das Durchsehen der Musterlösung.\nLG Roland");

	printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

    return 0;

}



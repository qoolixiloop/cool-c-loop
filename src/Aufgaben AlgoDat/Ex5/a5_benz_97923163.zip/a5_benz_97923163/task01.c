#include <stdio.h>
#include<stdlib.h>
//Roland Benz 97923163
//gcc -o task01 task01.c


int main(void)
{
    	printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    	printf("Hoi Livio,\n Ich konnte diese Woche, nach Zwischentest und Modelling Übung,\n nicht noch mehr Zeit für Info 2 aufwenden.\nLG Roland");

	printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

    return 0;

}


